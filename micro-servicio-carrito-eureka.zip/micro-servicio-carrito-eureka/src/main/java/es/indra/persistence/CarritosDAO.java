package es.indra.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;

import es.indra.models.Carrito;

public interface CarritosDAO extends MongoRepository<Carrito, String>{
	
	public Carrito findByUsuario(String usuario);

}
