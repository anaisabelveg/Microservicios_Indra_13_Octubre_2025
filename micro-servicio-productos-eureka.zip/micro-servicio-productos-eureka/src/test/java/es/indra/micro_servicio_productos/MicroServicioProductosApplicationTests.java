package es.indra.micro_servicio_productos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicioProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
