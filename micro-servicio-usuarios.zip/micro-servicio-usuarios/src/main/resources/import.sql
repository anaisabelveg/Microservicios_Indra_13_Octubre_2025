INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('juan', '$2a$10$cTIMeCuOaBVhUvyLmdcwA.hKe9erFTU9/58aAq8iylceJpT2vM97u', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('admin', '$2a$10$C1OXmO8qNbxHGgbQeTXAVe3NV.QEA8x/FIBB.U.6FGHp/gm9q1Fgm', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles (nombre) VALUES ('ROLE_USER');
INSERT INTO roles (nombre) VALUES ('ROLE_ADMIN');

INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (1,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,2);