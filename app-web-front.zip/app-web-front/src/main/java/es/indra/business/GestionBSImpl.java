package es.indra.business;

import java.util.List;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import es.indra.models.Carrito;
import es.indra.models.Producto;

@Service
public class GestionBSImpl  implements IGestionBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public List<Producto> obtenerTodos() {
		String url = "http://localhost:8090/api/productos/listar";
		Object[] array = restTemplate.getForEntity(url, Object[].class).getBody();
		ObjectMapper mapper = new ObjectMapper();
		return Arrays.stream(array)
				.map(object -> mapper.convertValue(object, Producto.class))
				.collect(Collectors.toList());
	}

	@Override
	public Producto buscar(Long id) {
		String url = "http://localhost:8090/api/productos/buscar/{id}";
		return restTemplate.getForObject(url, Producto.class, id);
	}

	@Override
	public Carrito consultar(String usuario) {
		String url = "http://localhost:8090/api/carrito/consultar/{usuario}";
		return restTemplate.getForObject(url, Carrito.class, usuario);
	}

	@Override
	public Carrito crear(String usuario) {
		String url = "http://localhost:8090/api/carrito/crear/{usuario}";	
		return restTemplate.postForObject(url, null, Carrito.class, usuario);
	}

	@Override
	public void agregar(Long id, int cantidad, String usuario) {
		String url = "http://localhost:8090/api/carrito/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}";
		restTemplate.put(url, null, id, cantidad, usuario);
	}

	@Override
	public void eliminar(Long id, String usuario) {
		String url = "http://localhost:8090/api/carrito/eliminar/id/{id}/usuario/{usuario}";
		restTemplate.delete(url, id, usuario);
	}

}
