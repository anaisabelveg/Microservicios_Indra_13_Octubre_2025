package es.indra.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.indra.business.IGestionBS;
import es.indra.models.Producto;

@Controller
@RequestMapping("/buscar")
public class BuscarController {
	
	@Autowired
	private IGestionBS bs;
	
	@RequestMapping(method = RequestMethod.GET)
	public String mostrarFormulario(Model model) {
		model.addAttribute("prod", new Producto());
		return "formBuscar";
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String procesarFormulario(@ModelAttribute("prod") Producto producto, Model model) {
//		Producto encontrado = bs.buscar(producto.getID());
//		if (encontrado.getDescripcion() == null) {
//			model.addAttribute("msg", "Ese producto no existe en nuestro catalogo");
//			return "mostrarMensaje";
//		} else {
//			model.addAttribute("encontrado", encontrado);
//			return "mostrarProducto";
//		}	
		
		try {
			Producto encontrado = bs.buscar(producto.getID());
			model.addAttribute("encontrado", encontrado);
			return "mostrarProducto";
		} catch (Exception e) {
			model.addAttribute("msg", "Ese producto no existe en nuestro catalogo");
			return "mostrarMensaje";
		}
	}

}
