package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
@EnableEurekaClient
public class MicroServicioProductosApplication implements CommandLineRunner{
	
	@Autowired  // DI
	private ProductosDAO dao;

	
	// El metodo main se dedica exclusivamente a levantar el contexto de Spring
	public static void main(String[] args) {
		// Levantar el contexto de Spring
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

	// El metodo run() se ejecuta de forma automatica despues del metodo main
	@Override
	public void run(String... args) throws Exception {
		// Crear nuevo producto
		dao.save(new Producto("Prueba", 777));
		
		// Mostrar todos los productos
		dao.findAll().forEach(System.out::println);
		System.out.println("------------------");
		
		System.out.println(dao.findByDescripcion("Scanner"));
		System.out.println("------------------");
		
		dao.findByPrecioBetween(50, 200).forEach(System.out::println);
		System.out.println("------------------");
		
		dao.findByPrecioBetweenOrderByDescripcion(50, 200).forEach(System.out::println);
		System.out.println("------------------");
		
		dao.findByPrecioBetweenOrderByDescripcionDesc(50, 200).forEach(System.out::println);
		System.out.println("------------------");
		
		dao.miQuery(100).forEach(System.out::println);
		System.out.println("------------------");
		
	}

}
