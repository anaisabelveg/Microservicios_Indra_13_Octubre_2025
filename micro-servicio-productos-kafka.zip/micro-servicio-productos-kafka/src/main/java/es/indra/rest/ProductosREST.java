package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.kafka.Productor;
import es.indra.models.Producto;

@RestController
@Validated  // Necesario para activar las validaciones
public class ProductosREST {
	
	@Value("${server.port}")    // se utiliza para inyectar valores (primitivos y String)
	private Integer port;
	
	@Autowired  // se utiliza para inyectar beans
	private IProductosBS bs;
	
	@Autowired
	private Productor productor;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		// 1ª opcion recorrer la lista de productos con bucle for y asignar el puerto a cada producto
//		List<Producto> lista = bs.consultarTodos();
//		for (Producto producto : lista) {
//			producto.setPort(port);
//		}
//		return lista;
		
		// 2ª opcion utilizando los streams de Java 8
		return bs.consultarTodos()
					.stream()
					.map(prod -> {
						prod.setPort(port);
						return prod;
					})
					.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/3
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") @Min(1) @Max(7)  Long id) {
		Producto producto = bs.buscarProducto(id);
		
		// Si el producto no existe lanzo una excepcion
		if (producto.getDescripcion() == null) {
			throw new RuntimeException("Ese producto no existe");
		}
		
		producto.setPort(port);
		return producto;
	}
	
	
	@GetMapping("/enviar/{id}/mensaje/{mensaje}")
	public void enviar(@PathVariable Long id, @PathVariable String mensaje) {
		Producto producto = bs.buscarProducto(id);
		String comentario = mensaje + " del producto " + producto;
		productor.enviarComentario(comentario);
	}
	

}












