package es.indra.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class JavaConfig {
	
	@Bean  // convierto el objeto java que retorna el metodo en un bean de Spring
	// El id del bean es el nombre del metodo
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
