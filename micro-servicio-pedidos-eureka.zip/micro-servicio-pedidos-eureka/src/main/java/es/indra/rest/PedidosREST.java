package es.indra.rest;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@RestController
public class PedidosREST {
	
	@Autowired  // No permite especificar el nombre del bean a inyectar
	// 1ª solucion es @Qualifier(nombre_bean)
	//@Qualifier(value = "pedidosBSImplFeign")
	//@Qualifier(value = "feign")
	// 2ª solucion es con la anotacion @Primary damos prefencia en la DI
	// 3ª solucion es inyectar con @Resource que si permite el nombre del bean
	//@Resource(name = "feign")
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/4/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	//@HystrixCommand(fallbackMethod = "manejarError")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// El problema de Hystrix es que necesitamos un metodo alternativo para cada
	// operacion del servicio, si tengo 25 operaciones, necesito 25 metodos alternativos
	// SOLUCION: implementar una captura global de excepciones en una clase aparte
	
	
	// Este metodo alternativo debe retornar lo mismo que el original
	// y recibir los mismos parametros + excepcion
	public Pedido manejarError( Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + " ********************");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Pedido(producto, cantidad);
	}

}
