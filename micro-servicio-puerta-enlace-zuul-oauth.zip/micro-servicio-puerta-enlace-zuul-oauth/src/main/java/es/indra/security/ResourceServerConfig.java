package es.indra.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

@Configuration
@EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter{
	
	@Override
	public void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests(
				requests -> requests.antMatchers("/api/security/oauth/**").permitAll()
				       .antMatchers(HttpMethod.GET, "/api/productos/listar").permitAll()
				       .antMatchers(HttpMethod.GET, "/api/carrito/consultar/{usuario}").hasAnyRole("ADMIN","USER")
				       .antMatchers("/api/pedidos/**").hasRole("ADMIN")
				       .antMatchers("/api/productos/**").hasAnyRole("ADMIN","USER")
				       .antMatchers("/api/carrito/**").hasAnyRole("ADMIN","USER")
				       .anyRequest().authenticated());
	}
	
	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		resources.tokenStore(tokenStore());
	}
	
	@Bean
	public JwtTokenStore tokenStore() {
		return new JwtTokenStore(accessTokenConverter());
	}
	
	@Bean
	public JwtAccessTokenConverter accessTokenConverter() {
		JwtAccessTokenConverter tokenConverter = new JwtAccessTokenConverter();
		tokenConverter.setSigningKey("pepito_12345_aeiou");
		return tokenConverter;
	}

}
