package es.indra.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import es.indra.models.Producto;

// En Spring Boot al heredar de cualquier xxxxRepository lo reconoce como un bean de Spring
public interface ProductosDAO extends JpaRepository<Producto, Long>{

}
