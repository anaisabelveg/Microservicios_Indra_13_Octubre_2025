package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class MicroServicioProductosApplication implements CommandLineRunner{
	
	@Autowired  // DI
	private ProductosDAO dao;

	
	// El metodo main se dedica exclusivamente a levantar el contexto de Spring
	public static void main(String[] args) {
		// Levantar el contexto de Spring
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

	// El metodo run() se ejecuta de forma automatica despues del metodo main
	@Override
	public void run(String... args) throws Exception {
		// Crear nuevo producto
		dao.save(new Producto("Prueba", 777));
		
		// Mostrar todos los productos
		dao.findAll().forEach(System.out::println);
		
	}

}
