package es.indra.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class Consumidor {
	
	@KafkaListener(topics = "indra-cluster")
	public void recibirComentario(String comentario) {
		System.out.println("*************************************");
		System.out.println("Comentario recibido: " + comentario);
		System.out.println("*************************************");
	}

}
